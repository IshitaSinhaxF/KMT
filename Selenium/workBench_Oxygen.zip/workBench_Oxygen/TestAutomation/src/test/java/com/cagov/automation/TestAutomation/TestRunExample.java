package com.cagov.automation.TestAutomation;

import org.testng.annotations.Test;

public class TestRunExample {

	@Test
	public void exampleOfTestNgMaven() {
		System.out.println("This is TestNG-Maven Example");
	}
}
