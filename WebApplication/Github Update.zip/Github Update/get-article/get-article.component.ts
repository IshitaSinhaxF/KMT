import { Component, OnInit } from '@angular/core';

import {Popup} from 'ng2-opd-popup';

@Component({
  selector: 'app-get-article',
  templateUrl: './get-article.component.html',
  styleUrls: ['./get-article.component.css']
})
export class GetArticleComponent  {

  constructor(private popup:Popup) { }


   onFeedback(){
    this.popup.options.color="blue";
    this.popup.options.widthProsentage=100;
    this.popup.options.header="Feedback           "
    this.popup.show();
   
    console.log("feedback popup");
  }


}
